import sqlite3
import os
import uuid
from datetime import datetime
from typing import Optional, Dict, Any

from chatbot.database.memory.memory_manager import MemoryManager
from chatbot.database.usage.stats_manager import DatabaseManager

# Example usage (update other modules/code to use these directly)
memory_manager = MemoryManager()
db_manager = DatabaseManager()
