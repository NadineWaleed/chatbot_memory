import os
import sqlite3
import uuid
from datetime import datetime
from typing import Optional

class DatabaseManager:
    def __init__(self):
        self.db_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "usage_stats.db")
        )
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.init_database()

    def init_database(self):
        """Create database and tables for question usage."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS questions (
            id TEXT PRIMARY KEY,
            user_ip TEXT NOT NULL,
            question TEXT NOT NULL,
            answer TEXT,
            status TEXT NOT NULL CHECK(status IN ('success', 'error')),
            processing_time REAL NOT NULL,
            question_date TEXT NOT NULL,
            question_time TEXT NOT NULL,
            error_message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_ip ON questions(user_ip)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_status ON questions(status)')
        conn.commit()
        conn.close()

    def log_question(self, user_ip: str, question: str, answer: Optional[str],
                     status: str, processing_time: float, error_message: Optional[str] = None) -> str:
        """Add a new question record."""
        question_id = str(uuid.uuid4())
        current_datetime = datetime.now()
        question_date = current_datetime.date().isoformat()
        question_time = current_datetime.time().strftime('%H:%M:%S')

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
        INSERT INTO questions (id, user_ip, question, answer, status, processing_time,
                               question_date, question_time, error_message)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (question_id, user_ip, question, answer, status, processing_time,
              question_date, question_time, error_message))
        conn.commit()
        conn.close()

        return question_id

    def log_usage(self, user_ip, question, answer, processing_time, success=True, error_message=None):
        """Shortcut for logging success/error usage."""
        status = "success" if success else "error"
        return self.log_question(user_ip, question, answer, status, processing_time, error_message)
