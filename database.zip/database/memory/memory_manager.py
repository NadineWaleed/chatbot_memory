# -*- coding: utf-8 -*-
"""
Memory Manager with Auto Table Creation
---------------------------------------
Ensures chat_memory.db exists and has the required table.
Handles saving, loading, deleting, and listing user chat contexts.
"""

import os
from datetime import datetime
from chatbot.database.connections.sqlite_connection import get_connection
from chatbot.database.memory.serializers import serialize_json, deserialize_json
from chatbot.database.logging.event_logger import log_event, log_error

DB_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "chat_memory.db")
)


class MemoryManager:
    """Encapsulates JSON-based memory storage for user sessions."""

    def __init__(self):
        self.ensure_table_exists()

    # ============================================================
    def ensure_table_exists(self):
        """Ensure that chat_memory.db and user_memory table exist."""
        try:
            with get_connection(DB_PATH) as cursor:
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS user_memory (
                        user_ip TEXT PRIMARY KEY,
                        context_json TEXT,
                        updated_at TEXT
                    )
                """)
            log_event("memory_table_verified", {"db_path": DB_PATH})
        except Exception as e:
            log_error("ensure_table_failed", str(e), "MemoryManager.ensure_table_exists")

    # ============================================================
    @staticmethod
    def save_context(user_ip: str, messages):
        """Insert or update user chat memory as JSON."""
        try:
            serialized = serialize_json(messages)
            with get_connection(DB_PATH) as cursor:
                cursor.execute("""
                    INSERT OR REPLACE INTO user_memory (user_ip, context_json, updated_at)
                    VALUES (?, ?, ?)
                """, (user_ip, serialized, datetime.now().isoformat()))
            log_event("memory_saved", {"user_ip": user_ip, "messages": len(messages)})
        except Exception as e:
            log_error("save_memory_failed", str(e), "MemoryManager.save_context")

    # ============================================================
    @staticmethod
    def load_context(user_ip: str):
        """Retrieve stored memory as Python list."""
        try:
            with get_connection(DB_PATH) as cursor:
                cursor.execute("SELECT context_json FROM user_memory WHERE user_ip = ?", (user_ip,))
                row = cursor.fetchone()
                if row and row[0]:
                    return deserialize_json(row[0])
            return []
        except Exception as e:
            log_error("load_memory_failed", str(e), "MemoryManager.load_context")
            return []

    # ============================================================
    @staticmethod
    def delete_context(user_ip: str):
        """Delete saved memory for a given user."""
        try:
            with get_connection(DB_PATH) as cursor:
                cursor.execute("DELETE FROM user_memory WHERE user_ip = ?", (user_ip,))
            log_event("memory_deleted", {"user_ip": user_ip})
        except Exception as e:
            log_error("delete_memory_failed", str(e), "MemoryManager.delete_context")

    # ============================================================
    @staticmethod
    def list_all_users():
        """List all users who have memory saved."""
        try:
            with get_connection(DB_PATH) as cursor:
                cursor.execute("""
                    SELECT user_ip, updated_at
                    FROM user_memory
                    ORDER BY updated_at DESC
                """)
                return cursor.fetchall()
        except Exception as e:
            log_error("list_users_failed", str(e), "MemoryManager.list_all_users")
            return []
