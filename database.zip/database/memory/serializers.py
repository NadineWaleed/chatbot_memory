import json
import zlib
from chatbot.database.logging.event_logger import log_error

ENABLE_COMPRESSION = False  # Optional: compress JSON to save space

def serialize_json(data):
    """Convert Python data → JSON string (optionally compressed)."""
    try:
        json_data = json.dumps(data, ensure_ascii=False)
        if ENABLE_COMPRESSION:
            return zlib.compress(json_data.encode("utf-8"))
        return json_data
    except Exception as e:
        log_error("json_serialize_failed", str(e), "serializers.serialize_json")
        return "[]"

def deserialize_json(blob):
    """Convert stored blob → Python object."""
    if not blob:
        return []
    try:
        if ENABLE_COMPRESSION:
            blob = zlib.decompress(blob).decode("utf-8")
        return json.loads(blob)
    except Exception as e:
        log_error("json_deserialize_failed", str(e), "serializers.deserialize_json")
        return []
