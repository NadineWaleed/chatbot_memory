# database/database_memory.py
import sqlite3
import json
import os
from datetime import datetime
from threading import Lock

MEMORY_DB_PATH = os.path.join("data", "memory_storage.db")
os.makedirs("data", exist_ok=True)


class MemoryDB:
    """SQLite memory storage with full chat stored as JSON per user (thread-safe)."""

    def __init__(self):
        self._lock = Lock()
        self._create_table()

    def _get_connection(self):
        """Create a thread-safe SQLite connection."""
        conn = sqlite3.connect(MEMORY_DB_PATH, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL;")  # better concurrency
        return conn

    def _create_table(self):
        """Initialize the memory table if it doesn't exist."""
        with self._get_connection() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS chat_memory (
                    user_id TEXT PRIMARY KEY,
                    messages_json TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

    def save_context(self, user_id: str, messages):
        """Save chat history as JSON string inside SQLite."""
        serialized = json.dumps(messages, ensure_ascii=False)
        with self._lock, self._get_connection() as conn:
            conn.execute("""
                INSERT INTO chat_memory (user_id, messages_json, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id)
                DO UPDATE SET
                    messages_json = excluded.messages_json,
                    updated_at = excluded.updated_at
            """, (user_id, serialized, datetime.now().isoformat()))

    def load_context(self, user_id: str):
        """Load JSON chat history for a user and return as Python list."""
        with self._lock, self._get_connection() as conn:
            cur = conn.execute("SELECT messages_json FROM chat_memory WHERE user_id = ?", (user_id,))
            row = cur.fetchone()
            if row and row[0]:
                try:
                    return json.loads(row[0])
                except json.JSONDecodeError:
                    return []
            return []

    def clear_context(self, user_id: str):
        """Remove a user’s chat record entirely."""
        with self._lock, self._get_connection() as conn:
            conn.execute("DELETE FROM chat_memory WHERE user_id = ?", (user_id,))


# ✅ Global instance
memory_db = MemoryDB()
