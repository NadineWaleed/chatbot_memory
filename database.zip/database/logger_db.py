# database/logger_db.py
"""
Legacy alias for event logging API. Actual logger implementations are now in chatbot/database/logging/event_logger.py
"""
from chatbot.database.logging.event_logger import log_event, log_error, log_performance, fetch_recent_logs
