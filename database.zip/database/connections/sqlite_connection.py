import sqlite3
from contextlib import contextmanager


def create_connection(db_path):
    """Create a thread-safe SQLite connection to the given path."""
    conn = sqlite3.connect(
        db_path,
        check_same_thread=False,
        timeout=10,
        isolation_level=None,
        detect_types=sqlite3.PARSE_DECLTYPES
    )
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn


@contextmanager
def get_connection(db_path):
    """Context manager for SQLite cursor (auto commit & rollback)."""
    conn = create_connection(db_path)
    try:
        cursor = conn.cursor()
        yield cursor
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
