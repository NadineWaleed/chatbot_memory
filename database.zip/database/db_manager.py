# -*- coding: utf-8 -*-
"""
Database Manager (Compatibility Layer)
--------------------------------------
Unifies access to memory manager and logging for backward compatibility.
"""
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from chatbot.database.memory.memory_manager import MemoryManager
from chatbot.database.memory.serializers import serialize_json, deserialize_json
from chatbot.database.logger_db import log_event, log_error

memory_manager = MemoryManager()

def log_usage(user_ip: str, action: str, metadata: dict | None = None):
    """
    Compatibility wrapper for logging user usage actions.
    Routes the log to logger_db.
    """
    try:
        log_event(
            event="log_usage",
            details=f"{action} | {user_ip}",
            context=metadata or {}
        )
    except Exception as e:
        log_error("log_usage_failure", str(e), "db_manager.log_usage")
