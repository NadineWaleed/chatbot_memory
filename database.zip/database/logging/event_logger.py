import os
import json
import sqlite3
from datetime import datetime
from contextlib import contextmanager
from chatbot.database.connections.sqlite_connection import get_connection

# Path for logger DB (local to /database/logging)
DB_PATH = os.path.join(os.path.dirname(__file__), "..", "system_logs.db")
DB_PATH = os.path.abspath(DB_PATH)

# ========================
# Initialize logger tables
# ========================
def init_logger_db():
    with get_connection(DB_PATH) as cursor:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                level TEXT,
                event_type TEXT,
                details TEXT,
                timestamp TEXT
            )
        """)
    print(f"✅ Logger database initialized at: {DB_PATH}")

# ========================
# Core logging functions
# ========================
def _insert_log(level: str, event_type: str, details: dict):
    """Private helper to insert a structured log."""
    with get_connection(DB_PATH) as cursor:
        cursor.execute("""
            INSERT INTO logs (level, event_type, details, timestamp)
            VALUES (?, ?, ?, ?)
        """, (
            level,
            event_type,
            json.dumps(details, ensure_ascii=False),
            datetime.now().isoformat()
        ))

# ========================
# Public API
# ========================
def log_event(event_type: str, details: dict = None):
    """Log general system or chat events."""
    _insert_log("INFO", event_type, details or {})

def log_error(event_type: str, error_message: str, source: str = None):
    """Log errors and exceptions."""
    _insert_log("ERROR", event_type, {
        "error": error_message,
        "source": source
    })

def log_performance(event_type: str, process_name: str, duration: float):
    """Log performance timing metrics."""
    _insert_log("PERFORMANCE", event_type, {
        "process": process_name,
        "duration_seconds": round(duration, 3)
    })

def fetch_recent_logs(limit: int = 20):
    """Retrieve recent logs for debugging."""
    with get_connection(DB_PATH) as cursor:
        cursor.execute("SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,))
        rows = cursor.fetchall()
        return [
            {
                "id": r[0],
                "level": r[1],
                "event_type": r[2],
                "details": json.loads(r[3]),
                "timestamp": r[4]
            } for r in rows
        ]

# ========================
# Initialize on import
# ========================
init_logger_db()
