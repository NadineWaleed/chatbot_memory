# embeddings/loader.py
import os
from pathlib import Path
from typing import List
from langchain_community.document_loaders import (
    PyPDFLoader,
    Docx2txtLoader,
    TextLoader,
    UnstructuredFileLoader
)
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from config import EMBEDDINGS_PATH, VECTORSTORE_DIR, DOCUMENTS_DIR

class EmbeddingsLoader:
    def __init__(self):
        self.documents_dir = DOCUMENTS_DIR
        self.vectorstore_dir = VECTORSTORE_DIR
        #Use the direct path to the embeddings model
        self.embeddings_model_path = EMBEDDINGS_PATH
        
    def load_documents(self) -> List:
        """load documents from the specified folder"""
        documents = []
        
        if not os.path.exists(self.documents_dir):
            print(f"⚠️ مجلد المستندات غير موجود: {self.documents_dir}")
            print(f"   يرجى وضع المستندات في: {self.documents_dir}")
            return documents
        
        supported_extensions = {'.pdf', '.docx', '.doc', '.txt'}
        found_files = 0
        
        for file_path in Path(self.documents_dir).rglob('*'):
            if file_path.suffix.lower() in supported_extensions:
                found_files += 1
                try:
                    if file_path.suffix.lower() == '.pdf':
                        loader = PyPDFLoader(str(file_path))
                    elif file_path.suffix.lower() in ['.docx', '.doc']:
                        loader = Docx2txtLoader(str(file_path))
                    elif file_path.suffix.lower() == '.txt':
                        loader = TextLoader(str(file_path), encoding='utf-8')
                    else:
                        loader = UnstructuredFileLoader(str(file_path))
                    
                    loaded_docs = loader.load()
                    for doc in loaded_docs:
                        doc.metadata['source'] = file_path.name
                    documents.extend(loaded_docs)
                    print(f"✅ تم تحميل: {file_path.name} ({len(loaded_docs)} مستند)")
                    
                except Exception as e:
                    print(f"❌ خطأ في تحميل {file_path.name}: {str(e)}")
        
        if found_files == 0:
            print(f"⚠️ لم يتم العثور على أي ملفات مدعومة في: {self.documents_dir}")
            print(f"   الملفات المدعومة: PDF, DOCX, DOC, TXT")
        else:
            print(f"📊 إجمالي المستندات المحملة: {len(documents)} من {found_files} ملف")
        
        return documents
    
    def split_documents(self, documents: List, chunk_size: int = 1000, chunk_overlap: int = 200):
        """Divide documents into smaller  chunk (parts)"""
        if not documents:
            return []
            
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
        )
        
        splits = text_splitter.split_documents(documents)
        print(f"📄 تم تقسيم المستندات إلى {len(splits)} جزء")
        return splits
    
    def create_embeddings(self, documents: List):
        """Create embeddings for documents"""
        if not documents:
            raise Exception("❌ لا توجد مستندات لإنشاء embeddings لها")
            
        print("🔄 جاري إنشاء الـ embeddings...")
        print(f"   استخدام النموذج من: {os.path.basename(self.embeddings_model_path)}")
        
        # Use embeddings pattern (model) from specified path
        embeddings = HuggingFaceEmbeddings(
            model_name=self.embeddings_model_path,
            model_kwargs={'device': 'cpu'},  #  CPU  
            encode_kwargs={'normalize_embeddings': True}
        )
        
        # Create vectors
        vectorstore = FAISS.from_documents(documents, embeddings)
        
        # Save vectors
        vectorstore.save_local(self.vectorstore_dir)
        print(f"💾 تم حفظ الـ embeddings في: {self.vectorstore_dir}")
        
        return vectorstore
    
    def load_existing_embeddings(self):
        """Download pre-existing embeddings"""
        try:
            # Check if the index.faiss file exists
            index_path = os.path.join(self.vectorstore_dir, "index.faiss")
            if os.path.exists(index_path):
                print(f"🔍 البحث عن الـ embeddings في: {self.vectorstore_dir}")
                
                embeddings = HuggingFaceEmbeddings(
                    model_name=self.embeddings_model_path,
                    model_kwargs={'device': 'cpu'},
                    encode_kwargs={'normalize_embeddings': True}
                )
                
                vectorstore = FAISS.load_local(
                    self.vectorstore_dir, 
                    embeddings, 
                    allow_dangerous_deserialization=True
                )
                print(f"✅ تم تحميل الـ embeddings الموجودة")
                return vectorstore
            else:
                print("⚠️ لا توجد embeddings محفوظة مسبقاً")
                return None
        except Exception as e:
            print(f"❌ خطأ في تحميل الـ embeddings: {str(e)}")
            return None
    
    def load(self):
        """The main function to load or create embeddings"""
        print("🚀 بدء تحميل نظام الـ embeddings...")
        print(f"   مسار النموذج: {self.embeddings_model_path}")
        print(f"   مجلد المتجهات: {self.vectorstore_dir}")
        print(f"   مجلد المستندات: {self.documents_dir}")
        
        # Trying to load existing embeddings
        vectorstore = self.load_existing_embeddings()
        
        if vectorstore is not None:
            return vectorstore
        
        # If it doesn't exist, create a new one.
        print("🔨 إنشاء الـ embeddings جديدة...")
        documents = self.load_documents()
        
        if not documents:
            raise Exception(f"❌ لم يتم العثور على أي مستندات في: {self.documents_dir}")
        
        splits = self.split_documents(documents)
        vectorstore = self.create_embeddings(splits)
        
        print("✅ تم تحميل نظام الـ embeddings بنجاح")
        return vectorstore
