# في كل مجلد (embeddings/, models/, chains/, interface/)
# __init__.py
