"""
Conversation Utility: Extracts conversation titles from conversation data.
"""
def titles(conversations):
    """Return list of conversation titles."""
    return [c["title"] for c in conversations] if conversations else []
