# -*- coding: utf-8 -*-
"""
Memory I/O Utilities (Modular Version)
--------------------------------------
Handles chat memory persistence between LangChain sessions
using the MemoryManager (JSON stored inside SQLite).
"""
import json
from typing import List, Dict, Any
from chatbot.database.db_manager import memory_manager
from chatbot.database.logging.event_logger import log_event, log_error

def load_memory(user_ip: str) -> List[Dict[str, Any]]:
    """
    Load stored chat memory for a user.
    Returns a list of LangChain message objects (dicts).
    """
    try:
        messages = memory_manager.load_context(user_ip)
        if not messages:
            log_event("memory_load_empty", {"user_ip": user_ip})
            return []
        if isinstance(messages, str):
            messages = json.loads(messages)
        log_event("memory_loaded", {"user_ip": user_ip, "count": len(messages)})
        return messages
    except json.JSONDecodeError as e:
        log_error("memory_load_json_error", str(e), "utils.memory.io.load_memory")
        return []
    except Exception as e:
        log_error("memory_load_failed", str(e), "utils.memory.io.load_memory")
        return []

def save_memory(user_ip: str, messages: List[Dict[str, Any]]):
    """
    Save chat memory for a user (list of message dicts).
    """
    try:
        if not messages:
            log_event("memory_save_skipped", {"user_ip": user_ip, "reason": "empty"})
            return
        memory_manager.save_context(user_ip, messages)
        log_event("memory_saved", {"user_ip": user_ip, "count": len(messages)})
    except TypeError as e:
        log_error("memory_save_type_error", str(e), "utils.memory.io.save_memory")
    except Exception as e:
        log_error("memory_save_failed", str(e), "utils.memory.io.save_memory")

def clear_memory(user_ip: str):
    """
    Clear the chat memory for a given user.
    """
    try:
        memory_manager.delete_context(user_ip)  # updated to match class definition
        log_event("memory_cleared", {"user_ip": user_ip})
    except Exception as e:
        log_error("memory_clear_failed", str(e), "utils.memory.io.clear_memory")
