# utils/health/system_health.py
from openai import OpenAI
from config import OPENAI_CONFIG

def test_server_connection():
    """Check if the configured API (OpenAI/Groq/local) is reachable."""
    try:
        client = OpenAI(**OPENAI_CONFIG)
        models = client.models.list()
        model_names = [m.id for m in models.data]
        return f"✅ تم الاتصال بنجاح. النماذج المتاحة: {', '.join(model_names[:3])}..."
    except Exception as e:
        return f"⚠️ لا يمكن الاتصال بالسيرفر: {e}"
