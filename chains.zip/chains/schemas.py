"""
Question Schemas: Pydantic models for input/output for LangChain QA
"""
from pydantic import BaseModel, Field
from typing import Optional, List

class QuestionRequest(BaseModel):
    """Input model for a user question."""
    question: str = Field(..., description="The user's question text.")
    user_ip: Optional[str] = Field(None, description="User's IP address if available.")

class QAResponse(BaseModel):
    """Output model containing the final answer and metadata."""
    original_question: str = Field(..., description="Original user question.")
    rephrased_question: str = Field(..., description="Question after rephrasing.")
    answer: str = Field(..., description="Generated answer from the RAG model.")
    sources: Optional[str] = Field("", description="Concatenated source documents or text.")
    request_id: str = Field(..., description="Unique ID for this question request.")

class ErrorResponse(BaseModel):
    """Used for returning a structured error message."""
    request_id: str = Field(..., description="Unique ID of the failed request.")
    error: str = Field(..., description="Error message.")
    details: Optional[str] = Field(None, description="Additional debug or context information.")

class SourceDocument(BaseModel):
    """Optional helper model if you want to structure document sources."""
    content: str
    metadata: Optional[dict] = None
