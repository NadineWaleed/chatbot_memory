import re

def clean_rephrased_question(rephrased_text: str) -> str:
    """Clean up the rephrased question text."""
    if not rephrased_text:
        return ""
    cleaned = rephrased_text.strip()
    cleaned = re.sub(r'^.*(الإجابة|الجواب|Answer|Response):\s*', '', cleaned)
    return cleaned.strip()
