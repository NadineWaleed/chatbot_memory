# -*- coding: utf-8 -*-
"""
Question Processor
------------------------
Handles the complete QA flow:
1. Rephrase user question
2. Retrieve & generate answer (RAG)
3. Persist chat memory (JSON → SQLite)
4. Log all steps for monitoring and analytics
"""

import os
import sys
import time
import uuid
from typing import Any, Union
from langchain.schema import HumanMessage, AIMessage

# ✅ Ensure project root in path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# ✅ Imports
from chatbot.chains.chains import ChainSetup
from chatbot.chains.schemas import QuestionRequest, QAResponse, ErrorResponse
from chatbot.chains.utils.cleaning import clean_rephrased_question
from chatbot.monitoring import monitor
from chatbot.database import db_manager
from chatbot.database.logger_db import log_event, log_error
from chatbot.utils.memory.io import load_memory, save_memory


class QuestionProcessor:
    """Main orchestrator for QA pipeline with persistent memory."""

    def __init__(self, embeddings: Any = None):
        self.chain_setup = ChainSetup()
        self.embeddings = embeddings

    # ======================================================================
    def process_question(self, data: QuestionRequest) -> Union[QAResponse, ErrorResponse]:
        """Run the full LangChain QA process."""
        request_id = str(uuid.uuid4())[:8]
        question_text = (data.question or "").strip()
        user_ip = data.user_ip

        monitor.log_question_received(question_text, request_id, user_ip)
        print(f"[{request_id}] 🟢 Received question: {question_text}")
        if user_ip:
            print(f"[{request_id}] 🌐 User IP: {user_ip}")

        try:
            # === Step 0: Restore previous chat memory (JSON from SQLite) ===
            previous_context = []
            if user_ip:
                previous_context = load_memory(user_ip)
                if previous_context:
                    print(f"[{request_id}] 🔄 Restored {len(previous_context)} messages from previous session.")

            # === Step 1: Initialize LangChain pipelines ===
            rephrase_chain, qa_chain = self.chain_setup.get_chains(user_ip=user_ip)

            # ✅ Restore messages into QA chain memory
            if hasattr(qa_chain, "memory") and previous_context:
                try:
                    qa_chain.memory.chat_memory.messages = [
                        HumanMessage(content=m["content"])
                        if m["role"] == "user"
                        else AIMessage(content=m["content"])
                        for m in previous_context
                    ]
                    print(f"[{request_id}] ✅ Memory restored into LangChain session.")
                except Exception as e:
                    print(f"[{request_id}] ⚠️ Failed to restore memory: {e}")

            # === Step 2: Rephrase Question ===
            monitor.log_rephrasing_start(request_id, question_text)
            t0 = time.time()
            try:
                rephrased = rephrase_chain.invoke({"question": question_text})
                rephrasing_time = time.time() - t0
            except Exception as e:
                rephrased = question_text
                rephrasing_time = 0
                log_error("rephrase_failure", str(e), "QuestionProcessor.rephrase")
                print(f"[{request_id}] ⚠️ Rephrase failed — using original question.")

            cleaned_question = clean_rephrased_question(rephrased)
            final_question = cleaned_question or question_text
            print(f"[{request_id}] 🔁 Final (cleaned) question: {final_question}")

            # === Step 3: Retrieve & Generate Answer ===
            monitor.log_qa_processing_start(request_id, final_question)
            t1 = time.time()
            try:
                result = qa_chain.invoke({"question": final_question})
                qa_time = time.time() - t1
            except Exception as e:
                raise RuntimeError(f"QA chain failed: {e}")

            # === Step 4: Extract Answer & Sources ===
            if isinstance(result, dict):
                final_answer = result.get("result", "")
                sources = result.get("source_documents", [])
                sources_text = "\n".join(map(str, sources)) if sources else ""
            else:
                final_answer = str(result)
                sources_text = ""

            total_time = rephrasing_time + qa_time
            print(f"[{request_id}] ✅ Answer: {final_answer[:120]}...")

            # === Step 5: Persist updated memory ===
            if hasattr(qa_chain, "memory") and qa_chain.memory:
                chat_history = qa_chain.memory.chat_memory.messages
                messages_json = []
                for msg in chat_history:
                    if isinstance(msg, HumanMessage):
                        messages_json.append({"role": "user", "content": msg.content})
                    elif isinstance(msg, AIMessage):
                        messages_json.append({"role": "assistant", "content": msg.content})

                if user_ip and messages_json:
                    save_memory(user_ip, messages_json)
                    log_event("memory_saved", {"user_ip": user_ip, "count": len(messages_json)})
                    print(f"[{request_id}] 💾 Memory saved for user {user_ip}.")

            # === Step 6: Log usage ===
            db_manager.log_usage(
                user_ip=user_ip,
                action="qa_session",
                metadata={
                    "question": question_text,
                    "answer_length": len(final_answer),
                    "processing_time": total_time,
                },
            )

            # === Step 7: Return structured response ===
            return QAResponse(
                original_question=question_text,
                rephrased_question=final_question,
                answer=final_answer,
                sources=sources_text,
                request_id=request_id,
            )

        # ------------------------------------------------------------------
        except Exception as e:
            error_msg = str(e)
            monitor.log_error(request_id, error_msg, "process_question")
            log_error("qa_failure", error_msg, "QuestionProcessor.process_question")
            print(f"[{request_id}] ❌ Error: {error_msg}")

            db_manager.log_usage(
                user_ip=user_ip,
                action="qa_error",
                metadata={"question": question_text, "error": error_msg},
            )

            return ErrorResponse(
                request_id=request_id,
                error="حدث خطأ تقني أثناء معالجة سؤالك.",
                details=error_msg,
            )
