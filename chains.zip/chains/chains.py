"""
Chain Pipeline Construction for LangChain QA (with memory persistence).
"""
#question/chains.py
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import RETRIEVAL_CONFIG
from chatbot.shared_embeddings import get_global_embeddings
from chatbot.models.openai_generator import OpenAIGenerator
from chatbot.models.chain_factory import build_rephrase_chain, build_qa_chain
from chatbot.prompts.templates import rephrase_prompt, qa_prompt
from chatbot.database.db_manager import memory_manager
from chatbot.database.logging.event_logger import log_event, log_error
from langchain.schema import HumanMessage, AIMessage

class ChainSetup:
    """
    Central controller for setting up and managing LangChain pipelines.
    Responsible for wiring models, prompts, retrievers, and persistence.
    """
    def __init__(self):
        self.rephrase_chain = None
        self.qa_chain = None
        self.user_ip = None  # track the current user/session

    def setup_chains(self, user_ip=None):
        """
        Initializes both rephrase and QA chains.
        Restores previous chat memory from DB (JSON-based) if available.
        """
        if self.rephrase_chain and self.qa_chain:
            return self.rephrase_chain, self.qa_chain

        embeddings = get_global_embeddings()
        if embeddings is None:
            raise ValueError("⚠️ الـ embeddings غير محملة. يرجى تشغيل main.py أولاً")

        llm = OpenAIGenerator()
        self.rephrase_chain = build_rephrase_chain(llm, rephrase_prompt)
        session_id = user_ip or "default_session"
        self.qa_chain = build_qa_chain(llm, qa_prompt, embeddings, use_memory=True, session_id=session_id)

        # Restore user memory from DB (JSON)
        if user_ip:
            self.user_ip = user_ip
            try:
                saved_context = memory_manager.load_context(user_ip)
                if saved_context and hasattr(self.qa_chain, "memory"):
                    for msg in saved_context:
                        role = msg.get("role")
                        content = msg.get("content", "")
                        if not content:
                            continue
                        if role == "user":
                            self.qa_chain.memory.chat_memory.add_message(HumanMessage(content=content))
                        elif role in ["assistant", "ai"]:
                            self.qa_chain.memory.chat_memory.add_message(AIMessage(content=content))
                    print(f"💾 Loaded previous JSON context for {user_ip} ({len(saved_context)} messages)")
                    log_event("memory_restored", {"user_ip": user_ip, "messages": len(saved_context)})
            except Exception as e:
                print(f"⚠️ Error restoring memory for {user_ip}: {e}")
                log_error("memory_restore_failed", str(e), "ChainSetup.setup_chains")

        print("✅ تم إعداد سلاسل LangChain مع ذاكرة المحادثة (JSON داخل SQLite) بنجاح")
        return self.rephrase_chain, self.qa_chain

    def save_context_to_db(self):
        """
        Save the chat history as a JSON array inside SQLite.
        Keeps last 10 messages to limit storage.
        """
        if not (self.qa_chain and hasattr(self.qa_chain, "memory") and self.user_ip):
            return
        try:
            messages = []
            for msg in self.qa_chain.memory.chat_memory.messages[-10:]:
                if isinstance(msg, HumanMessage):
                    messages.append({"role": "user", "content": msg.content})
                elif isinstance(msg, AIMessage):
                    messages.append({"role": "assistant", "content": msg.content})
            memory_manager.save_context(self.user_ip, messages)
            print(f"💾 JSON context saved for {self.user_ip} ({len(messages)} messages)")
            log_event("memory_saved", {"user_ip": self.user_ip, "messages": len(messages)})
        except Exception as e:
            print(f"⚠️ Failed to save JSON context for {self.user_ip}: {e}")
            log_error("memory_save_failed", str(e), "ChainSetup.save_context_to_db")

    def get_chains(self, user_ip=None):
        """Returns existing chains or creates them if not already initialized."""
        if not self.rephrase_chain or not self.qa_chain:
            return self.setup_chains(user_ip)
        return self.rephrase_chain, self.qa_chain
