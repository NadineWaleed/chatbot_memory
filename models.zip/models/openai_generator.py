# models/openai_generator.py
import time
from typing import Dict, Any
from openai import OpenAI
from langchain_core.runnables import Runnable
from langchain_openai import ChatOpenAI
from config import OPENAI_CONFIG, MODEL_CONFIG, MODEL_PATH

class OpenAIGenerator(Runnable):
    def __init__(self, system_prompt: str = None):
        self.model_name = MODEL_PATH
        self.max_tokens = MODEL_CONFIG["max_tokens"]
        self.temperature = MODEL_CONFIG["temperature"]
        self.last_request_time = 0
        self.request_delay = 2.0
        self.system_prompt = system_prompt or "أنت مساعد  ذكي للتامين الصحي ."
                
        #ChatOpenAI 
        self.llm = ChatOpenAI(
            model=MODEL_PATH,
            base_url=OPENAI_CONFIG["base_url"],
            api_key=OPENAI_CONFIG["api_key"],
            temperature=MODEL_CONFIG["temperature"],
            max_tokens=MODEL_CONFIG["max_tokens"],
            timeout=OPENAI_CONFIG["timeout"]
        )
        
    def generate(self, prompt: str) -> str:
        try:
            # add request_timeout ( calc time response ) (delay)
            current_time = time.time()
            time_since_last_request = current_time - self.last_request_time
            if time_since_last_request < self.request_delay:
                time.sleep(self.request_delay - time_since_last_request)
            
            self.last_request_time = time.time()
            
            # ChatOpenAI 
            messages = [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": prompt}
            ]
            
            response = self.llm.invoke(messages)
            
            if response and hasattr(response, 'content'):
                result = response.content.strip()
                print("تم استلام الرد بنجاح")
                return result
            else:
                print("⚠️ الرد فارغ")
                return prompt
                
        except Exception as e:
            print(f"خطأ في التوليد: {str(e)}")
            return prompt
    
    def invoke(self, input_data: Dict[str, Any], config=None, **kwargs) -> str:
        if isinstance(input_data, dict) and 'question' in input_data:
            prompt = str(input_data['question']).strip()
        else:
            prompt = str(input_data).strip()
        return self.generate(prompt)