from langchain.chains import RetrievalQA
from langchain_core.runnables import RunnablePassthrough
from langchain.memory import ConversationBufferMemory
from langchain.schema import HumanMessage, AIMessage
from config import RETRIEVAL_CONFIG
from chatbot.utils.memory.io import load_memory, save_memory


def build_rephrase_chain(llm, rephrase_prompt):
    return (
        {"question": RunnablePassthrough()}
        | rephrase_prompt
        | llm
    )


def build_qa_chain(llm, qa_prompt, embeddings, use_memory=True, session_id="default"):
    retriever = embeddings.as_retriever(**RETRIEVAL_CONFIG)

    memory = None
    if use_memory:
        memory = ConversationBufferMemory(
            memory_key="chat_history",
            input_key="question",
            output_key="result",
            return_messages=True,
        )

        # 🔁 Load previous context (if available)
        messages = load_memory(session_id)
        if messages:
            memory.chat_memory.messages = messages

    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
        chain_type_kwargs={"prompt": qa_prompt},
        input_key="question"
    )

    if memory:
        qa_chain.memory = memory

        # ✅ Automatically save context after each run
        orig_call = qa_chain.__call__

        def wrapped_call(inputs, *args, **kwargs):
            result = orig_call(inputs, *args, **kwargs)
            save_memory(session_id, memory.chat_memory.messages)
            return result

        qa_chain.__call__ = wrapped_call

    return qa_chain
