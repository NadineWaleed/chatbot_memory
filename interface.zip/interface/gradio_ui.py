"""
Gradio-based UI for the Healthcare Assistant Chatbot.
Provides both standalone launch and embedding for ASGI (uvicorn/FastAPI) environments.
All backend chat logic resides in chatbot.interface.chat_handlers.
"""

import gradio as gr
from monitoring import monitor
from interface import chat_handlers
from utils.health.system_health import test_server_connection

def handle_user_input(message, conversations, active_idx):
    """Wrapper for user message: routes event to backend handler."""
    return chat_handlers.send_message(message, conversations, active_idx)

def update_chat_history(history, user_message, bot_response):
    """Updates chat history display (utility for future UI extension)."""
    history.append({"role": "user", "content": user_message},)
    history.append({"role": "assistant", "content": bot_response},)
    return history

def launch_ui():
    """
    Builds and returns the Gradio Blocks app. 
    Use return value for .launch() (standalone) or pass to ASGI (e.g. FastAPI/uvicorn).
    """
    print(test_server_connection())
    monitor.log_system_event("gradio_interface_starting", {
        "status": "starting",
        "port": 7862
    })
    with gr.Blocks(
        css="""
            .gradio-container { background-color:#111827; color:#fff; }
            .title { text-align:center; font-size:28px; font-weight:700; margin: 10px 0 16px; }
            .sidebar { border-right:1px solid #1f2937; padding-right:8px; }
            .chatbot .wrap.svelte-1ax1roq { background:#0b1220; }
        """,
        theme=gr.themes.Base(),
    ) as demo:
        state_conversations = gr.State([])    # [{title:str, messages:[{role, content}, ...]}, ...]
        state_active_idx = gr.State(None)
        gr.HTML("<div class='title'>المساعد الذكي للتأمين الصحي</div>")
        with gr.Row():
            # === Sidebar ===
            with gr.Column(scale=1, min_width=240, elem_classes=["sidebar"]):
                gr.Markdown("### 📂 المحادثات")
                new_chat_btn = gr.Button("➕ محادثة جديدة", variant="primary")
                chat_list = gr.Radio(
                    label="المحادثات السابقة",
                    choices=[],
                    value=None,
                    interactive=True,
                )
            # === Chat area ===
            with gr.Column(scale=3):
                chatbot = gr.Chatbot(
                    label="الدردشة",
                    height=520,
                    type="messages",          # ensures Chatbot expects dicts with role/content
                    render_markdown=True,
                )
                user_input = gr.Textbox(
                    placeholder="اكتب سؤالك هنا ثم اضغط Enter…",
                    label="📝 ادخل السؤال"
                )
                send_btn = gr.Button("إرسال", variant="secondary")
        # ---- Bind UI Events ----
        new_chat_btn.click(
            fn=chat_handlers.new_chat,
            inputs=[state_conversations, state_active_idx],
            outputs=[state_conversations, state_active_idx, chat_list, chatbot, user_input],
        )
        send_btn.click(
            fn=handle_user_input,
            inputs=[user_input, state_conversations, state_active_idx],
            outputs=[state_conversations, state_active_idx, chat_list, chatbot, user_input],
        )
        user_input.submit(
            fn=handle_user_input,
            inputs=[user_input, state_conversations, state_active_idx],
            outputs=[state_conversations, state_active_idx, chat_list, chatbot, user_input],
        )
        chat_list.change(
            fn=chat_handlers.load_conversation,
            inputs=[chat_list, state_conversations],
            outputs=[state_conversations, state_active_idx, chat_list, chatbot],
        )
        demo.load(
            fn=chat_handlers.new_chat,
            inputs=[state_conversations, state_active_idx],
            outputs=[state_conversations, state_active_idx, chat_list, chatbot, user_input],
        )
    monitor.log_system_event("gradio_interface_launched", {
        "status": "success",
        "port": 7862
    })
    return demo

if __name__ == "__main__":
    app = launch_ui()
    # Use localhost instead of 0.0.0.0 for browser-accessible demo
    app.launch(server_name="localhost", server_port=7862, share=True)
