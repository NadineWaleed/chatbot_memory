"""
Backend Handlers for Chatbot UI
-------------------------
These functions process chat events for the Gradio interface (or any future UI).
Import and use as backend logic, keeping UI/transport code in gradio_ui.py or elsewhere.
"""
import time
import gradio as gr
from chatbot.chains.processor import QuestionProcessor
from chatbot.chains.schemas import QuestionRequest
from chatbot.utils.network.ip_utils import get_local_ip
from chatbot.utils.network.conversation_utils import titles
from chatbot.utils.memory.io import save_memory, load_memory, clear_memory
from chatbot.database.logger_db import log_event, log_error, log_performance

processor = QuestionProcessor()

def new_chat(conversations, active_idx):
    """Starts a new conversation session and returns updated state for UI."""
    if conversations is None:
        conversations = []
    new_idx = len(conversations) + 1
    conversations.append({"title": f"محادثة {new_idx}", "messages": []})
    active_idx = len(conversations) - 1
    title_list = titles(conversations)
    log_event("new_chat_created", {"total_conversations": len(conversations), "active_index": active_idx})
    return (
        conversations,
        active_idx,
        gr.update(choices=title_list, value=title_list[active_idx]),
        [],
        ""
    )

def send_message(user_text, conversations, active_idx):
    """Process sending a user message, route to QA, return updated UI/chatbot states."""
    if not user_text.strip():
        title_list = titles(conversations or [])
        current_msgs = [] if not conversations else conversations[active_idx]["messages"]
        return conversations, active_idx, gr.update(choices=title_list), current_msgs, ""
    if conversations is None:
        conversations = []
    if active_idx is None or active_idx >= len(conversations):
        conversations.append({"title": f"محادثة {len(conversations)+1}", "messages": []})
        active_idx = len(conversations) - 1
    request_id = f"gradio_{int(time.time())}_{active_idx}"
    start_time = time.time()
    user_ip = get_local_ip()
    log_event("gradio_message_received", {
        "request_id": request_id,
        "active_index": active_idx,
        "message_length": len(user_text),
        "message_preview": user_text[:100] + "..." if len(user_text) > 100 else user_text
    })
    try:
        saved_context = load_memory(user_ip) or []
        question_request = QuestionRequest(
            question=user_text,
            user_ip=user_ip,
        )
        answer = processor.process_question(question_request)
        if hasattr(answer, "dict"):
            answer_dict = answer.dict()
            bot_reply = answer_dict.get("answer", "عذرًا، حدثت مشكلة أثناء توليد الرد.")
        else:
            bot_reply = str(answer)
        processing_time = time.time() - start_time
        log_performance(request_id, "gradio_message_processing", processing_time)
        log_event("gradio_message_processed", {
            "request_id": request_id,
            "success": True,
            "processing_time": round(processing_time, 3),
            "answer_length": len(bot_reply)
        })
    except Exception as e:
        bot_reply = f"⚠️ حدث خطأ: {str(e)}"
        log_error(request_id, str(e), "gradio_send_message")
        log_event("gradio_message_processed", {"request_id": request_id, "success": False, "error": str(e)})
    # Update conversation history
    conversations[active_idx]["messages"].extend([
        {"role": "user", "content": "👤 " + user_text},
        {"role": "assistant", "content": "🤖 " + bot_reply}
    ])
    # Update chat title if first message
    if len(conversations[active_idx]["messages"]) == 2:
        snippet = user_text.strip().replace("\n", " ")[:30]
        if snippet:
            conversations[active_idx]["title"] = snippet
            log_event("chat_title_updated", {"active_index": active_idx, "new_title": snippet})
    title_list = titles(conversations)
    current_msgs = conversations[active_idx]["messages"]
    return (
        conversations,
        active_idx,
        gr.update(choices=title_list, value=title_list[active_idx]),
        current_msgs,
        ""
    )

def load_conversation(selected_title, conversations):
    """Loads a previous chat session by title for recall via UI."""
    if conversations is None:
        conversations = []
    title_list = titles(conversations)
    if not title_list:
        return conversations, None, gr.update(choices=[], value=None), []
    try:
        idx = title_list.index(selected_title)
        log_event("conversation_loaded", {
            "conversation_index": idx,
            "conversation_title": selected_title,
            "message_count": len(conversations[idx]["messages"])
        })
    except ValueError:
        idx = None
    if idx is None:
        return conversations, None, gr.update(choices=title_list, value=None), []
    else:
        current_msgs = [
            {"role": msg["role"], "content": msg["content"]}
            for msg in conversations[idx]["messages"]
        ]
        return conversations, idx, gr.update(choices=title_list, value=selected_title), current_msgs

def reset_user_memory():
    """Clear the JSON memory for the current user for this session (button/special event)."""
    user_ip = get_local_ip()
    clear_memory(user_ip)
    log_event("user_memory_reset", {"user_ip": user_ip})
    return f"✅ تم حذف ذاكرة المستخدم {user_ip}"
